let btn=document.querySelector('#submit');
btn.addEventListener('click',buttonClick);
function buttonClick(){
    alert('Your Message is sent Successfully');
}


// // let menu = document.querySelector('#menu-bar');
// // let navbar = document.querySelector('.navbar');
// let header = document.querySelector('.header');
// let scrollTop = document.querySelector('.scroll-top');

// header.addEventListener('click', () =>{
//     header.classList.toggle('fa-times');
//     header.classList.toggle('active');
// });

// window.onscroll = () =>{

//     header.classList.remove('fa-times');
//     header.classList.remove('active'); 

//     if(window.scrollY > 250){
//         header.classList.add('active');
//     }else{
//         header.classList.remove('active');
//     }

//     if(window.scrollY > 250){
//         scrollTop.style.display = 'initial';
//     }else{
//         scrollTop.style.display = 'none';
//     }

// }
// setInterval(function(){
//     countDown();
// },1000)

